package com.springcloud.userservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.springcloud.userservice.VO.Department;
import com.springcloud.userservice.VO.ResponseTemplateVO;
import com.springcloud.userservice.entity.User;
import com.springcloud.userservice.repository.UserRepository;

@RestController
@RequestMapping("/v1/user")
public class UserController {
	
	@Autowired
	UserRepository user_repo;
	
	User user;
	
	
	@Autowired
	RestTemplate restTemplate;
	
	@PostMapping("/add")
	public ResponseEntity<User> saveUser(@RequestBody User user){
		
		return new ResponseEntity<>(user_repo.save(user),HttpStatus.CREATED);
		
	}
	
	@GetMapping("/{id}")
	public ResponseTemplateVO getUserWithDepartment(@PathVariable Long id){
		ResponseTemplateVO vo=new ResponseTemplateVO();
		Optional<User> user=user_repo.findById(id);
		User newUser=new User();
		newUser=user.get();
		Department department=restTemplate.getForObject("http://DEPARTMENT-SERVICE/v1/department/"+newUser.getDepartmentId(),Department.class);
		vo.setUser(newUser);
		vo.setDepartment(department);
		return vo;
	}
	
	
	

}
