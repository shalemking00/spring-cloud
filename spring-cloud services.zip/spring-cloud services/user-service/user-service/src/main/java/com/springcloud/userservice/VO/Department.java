package com.springcloud.userservice.VO;

public class Department {
	
	private Long id;
	private String name;
	private String address;
	private String code;
	
	
	
	
	public Department(Long id, String name, String address, String code) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.code = code;
	}
	
	public Department() {
		super();
		
	}

	public Long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getCode() {
		return code;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCode(String code) {
		this.code = code;
	}

}
