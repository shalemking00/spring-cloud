package com.springcloud.department.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.springcloud.department.entity.Department;
import com.springcloud.department.repository.DepartmentRepository;

public class DepartmentService {
	
	@Autowired
	private DepartmentRepository dep_Repo;
	
	Logger logger = LoggerFactory.getLogger(DepartmentService.class);
	
	public ResponseEntity<Department> saveDepartment(Department department) {
		logger.info("inside saveMethod in DepartmentService");
		return new ResponseEntity<>(dep_Repo.save(department),HttpStatus.CREATED);
	}

	public ResponseEntity<Department> getDepartmentById(Long Department_Id) {
		Optional<Department> filter=dep_Repo.findById(Department_Id);
		if(filter.isPresent()) {
			return new ResponseEntity<>(filter.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	

}
