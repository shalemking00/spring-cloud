package com.springcloud.department.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.springcloud.department.entity.Department;
import com.springcloud.department.repository.DepartmentRepository;
import com.springcloud.department.service.DepartmentService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/department")
@Slf4j
public class DepartmentController {
	
	@Autowired
	private DepartmentRepository dep_repo;
	 
	Logger logger = LoggerFactory.getLogger(DepartmentController.class);
	
	@PostMapping("/add")
	public ResponseEntity<Department> saveDepartment(@RequestBody Department department) {
		logger.info("inside saveDepartment method");
		logger.info("Dep details", department);
		
		return new ResponseEntity<>(dep_repo.save(department),HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
		logger.info("inside saveDepartment method");
		Optional<Department> filter=dep_repo.findById(id);
		if(filter.isPresent()) {
			return new ResponseEntity<>(filter.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Department> DeleteDepartmentById(@PathVariable Long id) {
		logger.info("inside DeleteDepartment method");
		Optional<Department> filter=dep_repo.findById(id);
		if(filter.isPresent()) {
			dep_repo.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}

}
